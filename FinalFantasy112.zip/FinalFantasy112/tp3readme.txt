Name: The backrooms of 112

Description: The backrooms of 112 is a raycasted procedurally generated 
             dungeon crawler featuring a real time battle system inspired
             by Final Fantasy 4.  


Instructions: Run main.py and read the tutorial first by clicking on it.

Libraries: NA 

Shortcut Commmands:
    - n: generate new level 
    - p: instantiate the combat system
    - g: trigger game over condition
    - h: fill combat gague
